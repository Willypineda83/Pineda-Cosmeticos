
---
layout: video.njk
title: Nuevo Labial Mate
slug: labial-mate
youtube: https://www.youtube.com/watch?v=XXXXXXXX
thumbnail: /images/uploads/labial-mate.jpg
tag: Nuevo
description: "Descubre el nuevo labial mate."
permalink: "/v/labial-mate/index.html"
---
